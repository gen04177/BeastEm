1 - Copy these files to /data/beastem/
2 - On the BeastEm home screen, run "telnet PS4-IP 8456" to start...


FMI, see: https://github.com/atoone/BeastEm

